package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;

public interface UserDao {
	//CRUD operations
	public boolean save(User user);
	public boolean update(User user);
	public boolean delete(User user);
	public User get(String id);
	
	public List<User> list();
}
