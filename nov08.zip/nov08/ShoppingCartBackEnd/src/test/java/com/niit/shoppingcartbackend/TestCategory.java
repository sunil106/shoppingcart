package com.niit.shoppingcartbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestCategory {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext Context=new AnnotationConfigApplicationContext();
		Context.scan("com.niit");
		Context.refresh();
		Context.getBean("category");
		
		System.out.println("The category instances is created successfully");
	}

}
