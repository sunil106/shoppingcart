package com.niit.shoppingcartbackend;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.model.Category;

import junit.framework.Assert;

public class CategoryTestCase {
@Autowired
static
AnnotationConfigApplicationContext context;
@Autowired
 Category category;
@Autowired
Category categoryDAO;
@BeforeClass
public static void init(){
	context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	context.refresh();
	
	Category categoryDAO=(Category)context.getBean("categoryDAO");
	Category category=(Category)context.getBean("category");
	System.out.println("The objects are created");
}
@Test
public void createCategoryTestCase(){
	category.setId("MOB_07");
	category.setDescription("This is Mobile Category");
	category.setName("Mob cate");
	
	boolean status=categoryDAO.save(category);
	Assert.assertEquals("create category Test Case",true,status);
}


}
