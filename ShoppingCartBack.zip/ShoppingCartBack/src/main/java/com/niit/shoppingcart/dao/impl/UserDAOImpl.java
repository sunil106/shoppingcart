package com.niit.shoppingcart.dao.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

@Repository("userDAO")

public class UserDAOImpl implements UserDAO {
	@Autowired
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional

	public boolean save(User user) {

		try {

			Session session = sessionFactory.openSession();
			session.save(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {

			e.printStackTrace();
			return false;
		}

	}

	@Transactional
	public boolean update(User user) {

		try {
			Session session = sessionFactory.openSession();
			session.save(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {

			e.printStackTrace();

			return false;
		}
	}

	@Transactional
	public boolean delete(User user) {

		try {
			Session session = sessionFactory.openSession();
			session.delete(user);
			session.flush();
			session.close();
			return true;
		} catch (HibernateException e) {

			e.printStackTrace();

			return false;
		}
	}

	@Transactional
	public User get(String id) {
		return (User) sessionFactory.openSession().get(User.class, id);

	}

	@Transactional
	public List<User> list() {

		String hql = "from User";
		Query q = sessionFactory.openSession().createQuery(hql);
		return q.list();
	}

}
