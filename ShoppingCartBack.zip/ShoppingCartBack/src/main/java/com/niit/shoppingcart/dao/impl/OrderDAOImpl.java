package com.niit.shoppingcart.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.OrderDAO;
import com.niit.shoppingcart.model.Order;

@Repository("orderDAO")
public class OrderDAOImpl implements OrderDAO {

	public OrderDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}


	private static final Logger log = LoggerFactory.getLogger(OrderDAOImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	public OrderDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public boolean save(Order order) {
		try {
			log.debug("Starting of the method save");
			Session session = sessionFactory.openSession();
			session.save(order);
			session.flush();
			session.close();
			log.debug("Ending of the method save");
			return true;
		} catch (HibernateException e) {
			log.error("Error occured : " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	@Transactional
	public boolean delete(Order order) {
		try {
			log.debug("Starting of the method delete");
			Session session = sessionFactory.openSession();
			session.delete(order);
			session.flush();
			session.close();
			log.debug("Ending of the method delete");
			return true;
		} catch (HibernateException e) {
			log.error("Error occured : " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}
	
	
	@Transactional
	public boolean saveOrUpdate(Order order) {
		try {
			log.debug("Starting of the method saveOrUpdate");
			Session session = sessionFactory.openSession();
			session.saveOrUpdate(order);
			session.flush();
			session.close();
			log.debug("Ending of the method saveOrUpdate");
			return true;
		} catch (HibernateException e) {
			log.error("Error occured : " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

}
