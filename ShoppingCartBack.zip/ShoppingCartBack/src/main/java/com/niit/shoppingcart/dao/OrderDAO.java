package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.Order;

public interface OrderDAO {
	public boolean save(Order order);

	public boolean delete(Order order);
	
	public boolean saveOrUpdate (Order order);
	
}
