package com.niit.shoppingcart.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.Cart;
@Repository("cartDAO")
public class CartDAOImpl implements CartDAO {

	private static Logger log = LoggerFactory.getLogger(CartDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public CartDAOImpl(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	public CartDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Transactional
	public List<Cart> list(String id) {
		log.debug("Starting of the method list");
		String hql = "from Cart where userID=" + "'" + id + "'" + " and status = " + "'N'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> list = (List<Cart>) query.list();
		log.debug("Ending of the method list");
		return list;
	}

	@Transactional
	public Cart get(String id) {
		log.debug("Starting of the method get");
		String hql = "from Cart where userID=" + "'" + id + "'" + " and status = " + "'N'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		log.debug("Ending of the method get");
		return null;

	}

	@Transactional
	public void save(Cart cart) {
		log.debug("Starting of the method save");
		cart.setId(getMaxId().toString());
		sessionFactory.openSession().save(cart);
		log.debug("Ending of the method save");

	}

	@Transactional
	public void update(Cart cart) {
		log.debug("Starting of the method update");
		sessionFactory.getCurrentSession().update(cart);
		log.debug("Ending of the method update");
	}

	@Transactional
	public String delete(String id) {
		log.debug("Starting of the method delete");
		Cart cart = new Cart();
		cart.setUserID(id);
		try {
			sessionFactory.getCurrentSession().delete(cart);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		log.debug("Ending of the method delete");
		return null;
	}

	@Transactional
	public Long getTotalAmount(String id) {
		log.debug("Starting of the method getTotalAmount");
		String hql = "select sum(price) from Cart where userID=" + "'" + id + "'" + " and status = " + "'N'";
		log.debug("hql" + hql);

		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		Long sum = (Long) query.uniqueResult();
		log.debug("sum = " + sum);
		log.debug("Ending of the method getTotalAmount");
		return sum;
	}

	@Transactional
	private Long getMaxId() {
		log.debug("Starting of the method getMaxId");

		Long maxID = 100L;
		try {
			String hql = "select max(id) from Cart";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			maxID = (Long) query.uniqueResult();
		} catch (HibernateException e) {
			log.debug("It seems this is first record setting initial id is 100:");
			maxID = 100L;
			e.printStackTrace();
		}
		log.debug("Max id :" + maxID);
		return maxID + 1;

	}

}
