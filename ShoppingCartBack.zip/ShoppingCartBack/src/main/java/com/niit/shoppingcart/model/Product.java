package com.niit.shoppingcart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "product")
@Component

public class Product {
	@Id
	@Column(name = "productid")
	private String id;
	@Column(name = "name")

	private String name;
	@Column(name = "price")

	private String price;
	private String categoryId;
	
	@ManyToOne
	@JoinColumn(name="categoryid",updatable=false,insertable=false,nullable=false)
	
	private Category category;

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategory_id(String categoryid) {
		this.categoryId = categoryid;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
}
