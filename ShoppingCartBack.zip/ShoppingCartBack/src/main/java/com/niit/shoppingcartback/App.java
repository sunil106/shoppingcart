package com.niit.shoppingcartback;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.shoppingcart.dao.impl.CategoryDAOImpl;
import com.niit.shoppingcart.model.Category;

/**
 * Hello world!
 *
 */
public class App 
{
	
	@Autowired
	static SessionFactory    sessionFactory;
	
	
    public static void main( String[] args )
    {
    	
        System.out.println( "Hello World!" );
       Category cc=new Category();
       
       cc.setId("CC11");
       cc.setDescription("aaaaaaaaaaaaa");
       cc.setName("xxxxxx"); 
       System.out.println( sessionFactory.toString());
        CategoryDAOImpl c=new CategoryDAOImpl(sessionFactory);
        
        System.out.println("xxxxx");
      System.out.println(  c.save(cc));
      
        
    }
}
