/*package com.niit.shoppingcartback;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.BillingAddressDAO;
import com.niit.shoppingcart.model.BillingAddress;

import junit.framework.Assert;

public class BillingAddressTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static BillingAddress billingaddress;
	@Autowired
	static BillingAddressDAO billingaddressDAO;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		System.out.println("aaaaaaaaaaaaaaaaaa");
		context.refresh();
		System.out.println("bbbbbbb");
		billingaddressDAO = (BillingAddressDAO) context.getBean("billingaddressDAO");

		billingaddress = (BillingAddress) context.getBean("billingAddress");

		System.out.println("The objects are created");
	}

	// @Test
	public void createBillingAddressTestCase() {
		billingaddress.setId("1o1");
		billingaddress.setHno("202");
		billingaddress.setStreet("Garia");
		billingaddress.setCity("Kolkata");
		billingaddress.setCountry("India");
		billingaddress.setPin("713301");
		boolean status = billingaddressDAO.save(billingaddress);
		System.out.println(status);
		Assert.assertEquals("create billingaddress test case", true, status);
	}

	// @Test
	public void listBillingAddressTestCase() {
		Assert.assertEquals("cre", 2, billingaddressDAO.list().size());
	}

	// @Test
	public void updateBillingAddressTestCase() {
		billingaddress.setId("102");
		billingaddress.setHno("203");
		billingaddress.setStreet("Hadapsar");
		billingaddress.setCity("Pune");
		billingaddress.setCountry("India");
		billingaddress.setPin("713303");

		boolean status = billingaddressDAO.save(billingaddress);
		System.out.println(status);
		Assert.assertEquals("create billingaddress test case", true, status);
	}

	// @Test
	public void deleteBillingAddressTestCase() {
		billingaddress.setId("103");

		boolean status = billingaddressDAO.delete(billingaddress);
		System.out.println(status);
		Assert.assertEquals("delete billingaddress test case", true, status);
	}

	//@Test
	public void getBillingAddressTestCase() {
		Assert.assertEquals("get billingaddress test case", null, billingaddressDAO.get("abcd"));
	}
	@Test
	public void getAllBillingAddressTestCase(){
		Assert.assertEquals("get all BillingAddress test case", 3, billingaddressDAO.list().size());

	}
}
*/