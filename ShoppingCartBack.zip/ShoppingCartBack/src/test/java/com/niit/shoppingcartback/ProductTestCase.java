package com.niit.shoppingcartback;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

import junit.framework.Assert;

public class ProductTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static Product product;
	@Autowired
	static ProductDAO productDAO;
	@BeforeClass
	public static void init(){
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		System.out.println("aaaaaaaaaaaaaaaaaa");
		context.refresh();
		System.out.println("bbbbbbb");
		productDAO =(ProductDAO) context.getBean("productDAO");
		System.out.println("cccccc");
		product=(Product) context.getBean("product");
		System.out.println("The objects are created");
	}
	//@Test
	public void createProductTestCase(){
		product.setId("102");
		product.setName("nokia");
		product.setPrice("10000");
		boolean status=productDAO.save(product);
		System.out.println(status);
		Assert.assertEquals("create Product test case", true, status);
	}
	//@Test
	public  void listProductTestCase()
	{
		Assert.assertEquals("cre", 3, productDAO.list().size());	
	}
	//@Test
	public void updateProductTestCase(){
		product.setId("103");
		product.setName("samsung");
		product.setPrice("8000");
		boolean status=productDAO.save(product);
		System.out.println(status);
		Assert.assertEquals("create Product test case", true, status);
	}
//	@Test
	public void deleteProductTestCase(){
		product.setId("101");
		boolean status=productDAO.delete(product);
		System.out.println(status);
	    Assert.assertEquals("delete Supplier test case", true, status);
	}
	@Test
	public void getProductTestCase(){
		Assert.assertEquals("get Supplier test case", null, productDAO.get("abcd"));
	}
	}


