package com.niit.shoppingcartback;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

import junit.framework.Assert;

public class CategoryTestCase {
@Autowired
static AnnotationConfigApplicationContext context;
@Autowired
static Category category;
@Autowired
static CategoryDAO categoryDAO;
@BeforeClass
public static void init(){
	context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	System.out.println("aaaaaaaaaaaaaaaaaa");
	context.refresh();
	System.out.println("bbbbbbb");
	categoryDAO =(CategoryDAO) context.getBean("categoryDAO");
	System.out.println("cccccc");
	category=(Category) context.getBean("category");
	System.out.println("The objects are created");
}
//@Test
public void createCategoryTestCase(){
	category.setId("sssss");
	category.setName("samsung");
	category.setDescription("this is mobile category");
	boolean status=categoryDAO.save(category);
	System.out.println(status);
	Assert.assertEquals("create category test case", true, status);
}
//@Test
public  void listCategoryTestCase()
{
	Assert.assertEquals("cre", 4, categoryDAO.list().size());	
}
//@Test
public void updateCategoryTestCase(){
	category.setId("DDDDD");
	category.setName("nokia");
	category.setDescription("this is mobile category");
	boolean status=categoryDAO.save(category);
	System.out.println(status);
	Assert.assertEquals("create category test case", true, status);
}
//@Test
public void deleteCategoryTestCase(){
	category.setId("101");
	boolean status=categoryDAO.delete(category);
	System.out.println(status);
    Assert.assertEquals("delete category test case", true, status);
}
//@Test
public void getCategoryTestCase(){
	Assert.assertEquals("get category test case", null, categoryDAO.get("abcd"));
}
//@Test
public void getAllCategoryTestCase(){
	Assert.assertEquals("get all category test case", 7, categoryDAO.list().size());

}
}