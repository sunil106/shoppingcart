/*package com.niit.shoppingcartback;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ShippingAddressDAO;
import com.niit.shoppingcart.model.ShippingAddress;

import junit.framework.Assert;

public class ShippingAddressTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static ShippingAddress shippingaddress;
	@Autowired
	static ShippingAddressDAO shippingaddressDAO;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		System.out.println("aaaaaaaaaaaaaaaaaa");
		context.refresh();
		System.out.println("bbbbbbb");
		shippingaddressDAO = (ShippingAddressDAO) context.getBean("shippingaddressDAO");

		shippingaddress = (ShippingAddress) context.getBean("shippingAddress");

		System.out.println("The objects are created");
	}

	//@Test
	public void createShippingAddressTestCase() {
		shippingaddress.setId("113");
		shippingaddress.setHno("304");
		shippingaddress.setStreet("Garia");
		shippingaddress.setCity("Kolkata");
		shippingaddress.setCountry("India");
		shippingaddress.setPin("713303");
		boolean status = shippingaddressDAO.save(shippingaddress);
		System.out.println(status);
		Assert.assertEquals("create shippingaddress test case", true, status);
	}
	//@Test
	public void listShippingAddressTestCase() {
		Assert.assertEquals("cre", 2, shippingaddressDAO.list().size());
	}
	//@Test
	public void updateShippingAddressTestCase() {
		shippingaddress.setId("113");
		shippingaddress.setHno("304");
		shippingaddress.setStreet("Hadapsar");
		shippingaddress.setCity("Pune");
		shippingaddress.setCountry("India");
		shippingaddress.setPin("713304");

		boolean status = shippingaddressDAO.save(shippingaddress);
		System.out.println(status);
		Assert.assertEquals("create shippingaddress test case", true, status);
	}
	// @Test
		public void deleteShippingAddressTestCase() {
		 shippingaddress.setId("110");

			boolean status = shippingaddressDAO.delete(shippingaddress);
			System.out.println(status);
			Assert.assertEquals("delete shippingaddress test case", true, status);
		}
		//@Test
		public void getShippingAddressTestCase() {
			Assert.assertEquals("get shippingaddress test case", null, shippingaddressDAO.get("abcd"));
		}
		@Test
		public void getAllShippingAddressTestCase(){
			Assert.assertEquals("get all ShippingAddress test case", 2, shippingaddressDAO.list().size());

		}
}
*/