/*package com.niit.shoppingcartback;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

import junit.framework.Assert;

public class SupplierTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static Supplier supplier;
	@Autowired
	static SupplierDAO supplierDAO;
	@BeforeClass
	public static void init(){
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		System.out.println("aaaaaaaaaaaaaaaaaa");
		context.refresh();
		System.out.println("bbbbbbb");
		supplierDAO =(SupplierDAO) context.getBean("supplierDAO");
		System.out.println("cccccc");
		supplier=(Supplier) context.getBean("supplier");
		System.out.println("The objects are created");
	}
//	@Test
	public void createSupplierTestCase(){
		supplier.setId("102");
		supplier.setName("nokia");
		supplier.setDescription("this is mobile category");
		boolean status=supplierDAO.save(supplier);
		System.out.println(status);
		Assert.assertEquals("create Supplier test case", true, status);
	}
	//@Test
	public  void listSupplierTestCase()
	{
		Assert.assertEquals("cre", 2, supplierDAO.list().size());	
	}
//	@Test
	public void updateSupplierTestCase(){
		supplier.setId("103");
		supplier.setName("samsung");
		supplier.setDescription("this is mobile category");
		boolean status=supplierDAO.save(supplier);
		System.out.println(status);
		Assert.assertEquals("create Supplier test case", true, status);
	}
	//@Test
	public void deleteSupplierTestCase(){
		supplier.setId("102");
		boolean status=supplierDAO.delete(supplier);
		System.out.println(status);
	    Assert.assertEquals("delete Supplier test case", true, status);
	}
	@Test
	public void getSupplierTestCase(){
		Assert.assertEquals("get Supplier test case", null, supplierDAO.get("abcd"));
	}
	@Test
	public void getAllSupplierTestCase(){
		Assert.assertEquals("get all Supplier test case", 5, supplierDAO.list().size());

	}
}
*/