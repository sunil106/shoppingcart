/*package com.niit.shoppingcartback;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

import junit.framework.Assert;


public class UserTestCase {
	@Autowired
	static AnnotationConfigApplicationContext context;
	@Autowired
	static User user;
	@Autowired
	static UserDAO userDAO;
	@BeforeClass
	public static void init(){
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		System.out.println("aaaaaaaaaaaaaaaaaa");
		context.refresh();
		System.out.println("bbbbbbb");
		userDAO =(UserDAO) context.getBean("userDAO");
		System.out.println("cccccc");
		user=(User) context.getBean("user");
		System.out.println("The objects are created");
	}	
//	@Test
	public void createUserTestCase(){
		user.setUserid("103");
		user.setPassword("234");
		user.setName("ashish");
		user.setRole("enduser");
		user.setEmail("qwe@gmail.com");
		boolean status=userDAO.save(user);
		System.out.println(status);
		Assert.assertEquals("create user test case", true, status);
	}
	//@Test
	public  void listUserTestCase()
	{
		Assert.assertEquals("cre", 1, userDAO.list().size());	
	}		
	//@Test
	public void updateUserTestCase(){
		user.setUserid("103");
		user.setPassword("234");
		user.setName("kanchan");
		user.setRole("enduser");
		user.setEmail("qwe@gmail.com");

		boolean status=userDAO.save(user);
		System.out.println(status);
		Assert.assertEquals("create Supplier test case", true, status);
	}
//	@Test
	public void deleteUserTestCase(){
		user.setUserid("103");
		
		boolean status=userDAO.delete(user);
		System.out.println(status);
	    Assert.assertEquals("delete Supplier test case", true, status);
	}
	//@Test
	public void getUserTestCase(){
		Assert.assertEquals("get User test case", null, userDAO.get("abcd"));
	}
	@Test
	public void getAllUserTestCase(){
		Assert.assertEquals("get all User test case", 0, userDAO.list().size());

	}
}
*/