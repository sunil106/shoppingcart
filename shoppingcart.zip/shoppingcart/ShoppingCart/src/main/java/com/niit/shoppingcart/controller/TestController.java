package com.niit.shoppingcart.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller 
@RequestMapping("/niit")
public class TestController {

	@RequestMapping("/sunil")
	public String test() {
		return "register";
	}

	@RequestMapping("/checklogin")
	public String checklogin(@RequestParam("userid") String userid, @RequestParam("password") String password,
			Model model) {

		if (userid.equals("niit") && password.equals("niit")) {
			model.addAttribute("successmessage", "you successfully logged in");
		} else {
			model.addAttribute("erroermessag", "invalid credentials please try again");
		}
		return "index";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	@RequestMapping("/header")
	public String head() {
		return "header";
	}
	@RequestMapping("/register")
	public ModelAndView regis(Model model) {
		ModelAndView mv=new ModelAndView("header");
		mv.addObject("userClickedResgister","true");
		return mv;
	}

}
