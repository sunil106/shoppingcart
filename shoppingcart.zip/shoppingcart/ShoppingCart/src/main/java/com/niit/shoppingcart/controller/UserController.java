package com.niit.shoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;

@Controller

public class UserController {
@Autowired
User user;
@Autowired
UserDAO userDAO;
@Autowired
private CategoryDAO categoryDAO;
@Autowired
private Category category;
@Autowired
private SupplierDAO supplierDAO;
@Autowired
private Supplier supplier;
@Autowired
private ProductDAO productDAO;
@Autowired
private Product product;
@Autowired
private HttpSession session;

/*if invalid credentials ->Home page,login ,error message if valid
 * credentials && he is admin  ->AdminHome page,logout link if valid
 * credentials && he is end user -> Home page,cart,logout link
 * 
 * @Param userID
 * @Param password
 * @Return it will return data and  page name where to return
 * 
 
 */
 @RequestMapping(value="/validate",method=RequestMethod.POST)
 public ModelAndView login(@RequestParam(value="username") String userID,@RequestParam(value="password") String password,HttpSession session )
 {   log.debug("starting of the method login");
 log.debug("userID is {} password is {}" ,userID ,password); 
 
 ModelAndView mv=new ModelAndView("/home");
 user = userDAO.isValidUser(userID,password);
 
 if (user != null){
	 log.debug("valid credentials");
	 user=userDAO.get(userID);
	 session.setAttribute("loggedInUser",user.getName());
	 session.setAttribute("loggedInUserID",user.getId());
	 session.setAttribute("user",user);
 }
 
 @RequestMapping(value="/validate",method=RequestMethod.POST)
 public ModelAndView validate (@RequestParam(value="username") String userID,@RequestParam(value="password") String password,HttpSession session )
 {   ModelAndView mv=new ModelAndView("/home");
 user = userDAO.isValidUser(userID,password);
 
 if (user != null){
	 List<Category> categoryList= categoryDAO.list();
	 mv.addObject("categoryList",categoryList);
	 //need to display in home page
	 mv.addObject("category",category);
	 
	 //if the credentials are valid,load all the categories
	 if (user.getRole().equals("ROLE USER")){
		 mv.addObject("isAdmin","false");	 
	 }
	 else {
		 //if the user is Admin
		 //we need product list and supplier list also
		 List<Product> productList= ProductDAO.list();
		 
		 //Admin will create/update delete/fetch all
		 
		 mv.addObject("productList",productList);
		 mv.addObject("supplierList",supplierList);
		 //from the list we should get supplier
		 mv.addObject("product",product);
		 mv.addObject("supplier",supplier);
		 mv.addObject("isAdmin","true");
	 }
 }
 else {
	 //if it is invalid credentials
	 mv.addObject("errorMessage","invalid credentials please try again ");
	 return mv;
 }
 }
}
