package com.niit.shoppingcart.view;
import java.io.Serializable;

import com.niit.shoppingcart.model.BillingAddress;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.User;


public class CheckoutDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	private BillingAddress billingAddress;
	
	private Cart cart;
	
	private User user;

	public CheckoutDetails(BillingAddress billingAddress, Cart cart, User user) {
		this.billingAddress = billingAddress;
		this.cart = cart;
		this.user = user;
	}
	public CheckoutDetails() {
	}	
	
	public BillingAddress getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	

}
