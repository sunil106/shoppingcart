package com.niit.shoppingcart.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;

import ch.qos.logback.core.util.FileUtil;

@Controller
public class ProductController {

	private static Logger log = LoggerFactory.getLogger(ProductController.class);

	@Autowired(required = true)
	private ProductDAO productDAO;
	@Autowired(required = true)
	private CategoryDAO categoryDAO;
	@Autowired(required = true)
	private Product product;
	@Autowired(required = true)
	private SupplierDAO supplierDAO;

	private String path = "resources/images/";

	@RequestMapping(value = "/manage_products", method = RequestMethod.GET)

	public String listProducts(Model model) {
		log.debug("Starting of the method listProducts");
		model.addAttribute("product", new Product());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("isAdminClickedProducts", "true");
		log.debug("Ending of the method listProducts");
		return "/home";
	}
	@RequestMapping(value = "/manage_product_add", method = RequestMethod.POST)
	public String saveOrUpdateProduct(@ModelAttribute("product") Product product, HttpServletRequest request,@RequestParam("file") MultipartFile file   ){
		System.out.println("bbbbb"+product.getId());
		log.debug("saveOrUpdateProduct method starts...");
		
		//String newID = Util.removeComma(product.getId());
		//System.out.println("aaaaaaaa"+newID);
		//product.setId(newID);
		
		byte fileBytes[];
		FileOutputStream fos = null;
		
		String fileName = "";
		String productImage = "";
		ServletContext context = request.getSession().getServletContext();

		String realContextPath = context.getRealPath("/");
		String un = product.getName();
		if (file != null){
			fileName = realContextPath + "/resources/images/" + un + ".jpg";
			productImage = "resources/images/" + un + ".jpg";
			System.out.println("===" + fileName + "===");
			File fileobj = new File(fileName);
			try{
				fos = new FileOutputStream(fileobj);
				fileBytes = file.getBytes();
				fos.write(fileBytes);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		/*String sid=product.getSupplier().getId();
		String cid=product.getCategory().getId();*/
		
		product.setProductImage(productImage);				

		/*Supplier ss=supplierDAO.get(sid);
		Category cc=categoryDAO.get(cid);
		System.out.println("supplier :"+ss.getId());
		System.out.println("supplier :"+cc.getName());*/
		/*product.setCategory(cc);
		product.setSupplier(ss);*/
		
		productDAO.saveOrUpdate(product);
		
		log.debug("saveOrUpdateProduct method ends...");
		return "redirect:/home";
	}	
	@RequestMapping("manage_product/delete/{id}")
	public String deleteProduct(@PathVariable("id") String id, Model model) throws Exception {
		log.debug("deleteProduct method starts...");		
		try{
			product = productDAO.get(id);
			productDAO.delete(product);
			model.addAttribute("message", "Successfully Deleted...");
		}
		catch(Exception e){
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}		
		log.debug("deleteProduct method ends...");
		return "redirect:/home";
	}
	  
	 
	@RequestMapping("manage_product/edit/{id}")
	public String editSelectedProduct(@PathVariable("id") String id, Model model, RedirectAttributes redirectAttributes){
		
		redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
		redirectAttributes.addFlashAttribute("selectedProductList", productDAO.list());
		redirectAttributes.addFlashAttribute("isAdminClickedProducts", "true");
		
		return "redirect:/editproduct";
	}
	
	
	@RequestMapping(value = "/editproduct", method = RequestMethod.GET)
	public String editProduct(@ModelAttribute("selectedProduct") final Object selectedProduct, @ModelAttribute("selectedProductList") final Object selectedProductList, Model model){
		
		model.addAttribute("product", selectedProduct);
		model.addAttribute("productList", selectedProductList);
		return "product"; 
	}


	@RequestMapping("/product/show/{categoryId}")
	public ModelAndView getAllProductByCategory(@PathVariable("categoryId") String categoryId) {
		List<Product> products = productDAO.list(categoryId);
		ModelAndView mv = new ModelAndView("products");
		if (products.isEmpty()) {
			mv.addObject("msg", "no products are available with the category Id" + categoryId);
		} else {
			mv.addObject("productList", products);
		}
		return mv;
	}
	
	
	
	@RequestMapping("/product/showSingleProduct/{productId}")
	public ModelAndView getAllProducts(@PathVariable("productId") String productId  , HttpSession session) {
		Product product = productDAO.get(productId);
		ModelAndView mv = new ModelAndView("selectedProduct");
		if (product == null) {
			mv.addObject("msg", "no products are available with the productId" + productId);
		} else {
			session.setAttribute("selectedProduct", product);
			mv.addObject("product", product);
		}
		return mv;
	}
	
	
	
	@RequestMapping(value = "/singleproduct", method = RequestMethod.GET)
	public String singleProduct(@ModelAttribute("selectedProduct") final Object selectedProduct, Model model) {
		log.debug("Starting of the method singleProduct");
		model.addAttribute("product", selectedProduct);
		model.addAttribute("categoryList", this.categoryDAO.list());
		log.debug("Ending of the method singleProduct");
		return "home";
	}
}
