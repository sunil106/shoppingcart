package com.niit.shoppingcart.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;

import ch.qos.logback.core.util.FileUtil;

@Controller
public class ProductController {

	private static Logger log = LoggerFactory.getLogger(ProductController.class);

	@Autowired(required = true)
	private ProductDAO productDAO;
	@Autowired(required = true)
	private CategoryDAO categoryDAO;
	@Autowired(required = true)
	private Product product;
	@Autowired(required = true)
	private SupplierDAO supplierDAO;

	private String path = "resources/images/";

	@RequestMapping(value = "/manage_products", method = RequestMethod.GET)

	public String listProducts(Model model) {
		log.debug("Starting of the method listProducts");
		model.addAttribute("product", new Product());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("isAdminClickedProducts", "true");
		log.debug("Ending of the method listProducts");
		return "/home";
	}

	/*@RequestMapping(value = "/manage_product_add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product, @RequestParam("image") MultipartFile file,
			Model model) {
		log.debug("Starting of the method addProduct");
		Category category = categoryDAO.getByName(product.getCategory().getName());
		Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		product.setCategory(category);
		product.setSupplier(supplier);
		String category_id;
		product.setCategory_id(category_id);
		String supplier_id;
		product.setSupplier_id(supplier_id);
		product.setId(com.niit.shoppingcart.util.Util.removeCommon(product.getId()));
		productDAO.saveOrUpdate(product);
		FileUtil.upload(path, file, product.getId() + ".jpg");
		log.debug("Ending of the method addProduct");
		model.addAttribute("isAdminClickedProducts", "true");
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("product", new Product());
		return "/home";
		// return "redirect:uploadfile";
	}*/

	/*@RequestMapping("manage_product/delete{id}")
	public String deleteProduct(@PathVariable("id") String id, Model model) throws Exception {
		log.debug("Starting of the method deleteProduct");
		try {
			product = productDAO.get(id);
			productDAO.delete(product);
			model.addAttribute("message", "Successfully deleted the product");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		log.debug("Ending of the method deleteProduct");
		return "redirect:/product";
	}

	@RequestMapping("manage_product/edit{id}")
	public String editSelectedProduct(@PathVariable("id") String id, Model model,
			RedirectAttributes redirectAttributes) {
		log.debug("Starting of the method editSelectedProduct");
		redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
		redirectAttributes.addFlashAttribute("selectedProductList", productDAO.list());
		redirectAttributes.addFlashAttribute("isAdminClickedProducts", "true");
		log.debug("Ending of the method editSelectedProduct");
		return "redirect:/editProduct";
	}

	@RequestMapping(value = "manage_product/edit/{id}", method = RequestMethod.GET)
	public String editProduct(@PathVariable("id") String id, Model model) {
		log.debug("Starting of the method editProduct");
		product = productDAO.get(id);
		model.addAttribute("selectedProduct", product);
		log.debug("Ending of the method editProduct");
		return "forward:/manage_products";
	}

	@RequestMapping(value = "manage_product/get/{id}")
	public ModelAndView getSelectedProduct(@PathVariable("id") String id, Model model,
			RedirectAttributes redirectAttributes) {
		log.debug("Starting of the method getSelectedProduct");
		ModelAndView mv = new ModelAndView("redirect:/home");
		redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
		log.debug("Ending of the method getSelectedProduct");
		return mv;
	}*/

	/*@RequestMapping("/search_product/{search_string}")
	public ModelAndView getAllProductBySearchString(@PathVariable("search_string") String search_string) {
		List<Product> products = productDAO.getSimilarProduct(search_string);
		ModelAndView mv = new ModelAndView("/home");
		if (products.isEmpty()) {
			mv.addObject("msg", "no products are available with the search text" + search_string);
		} else {
			mv.addObject("ProductList", products);
		}
		return mv;
	}

	@RequestMapping(value = "/singleproduct", method = RequestMethod.GET)
	public String singleProduct(@ModelAttribute("selectedProduct") final Object selectedProduct, Model model) {
		log.debug("Starting of the method singleProduct");
		model.addAttribute("product", selectedProduct);
		model.addAttribute("categoryList", this.categoryDAO.list());
		log.debug("Ending of the method singleProduct");
		return "home";
	}*/
	
	
	@RequestMapping("/listProducts/{categoryId}")
	public ModelAndView getAllProductByCategory(@PathVariable("categoryId") String categoryId) {
		List<Product> products = productDAO.list(categoryId);
		ModelAndView mv = new ModelAndView("products");
		if (products.isEmpty()) {
			mv.addObject("msg", "no products are available with the category " + categoryId);
		} else {
			mv.addObject("productList", products);
		}
		return mv;
	}
	
	
	
	
	
}
