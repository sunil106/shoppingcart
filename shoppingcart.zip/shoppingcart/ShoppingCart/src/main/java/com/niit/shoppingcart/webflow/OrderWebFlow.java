package com.niit.shoppingcart.webflow;

import javax.servlet.http.HttpSession;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.shoppingcart.model.BillingAddress;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.User;

@Component
public class OrderWebFlow {
	private static Logger log = LoggerFactory.getLogger(OrderWebFlow.class);

@Autowired
private ShippingAddress ShippingAddress;

@Autowired
private BillingAddress billingaddress;

@Autowired
private User user;

@Autowired
private OrderDAO orderDAO;

@Autowired
private CartDAO cartDAO;

@Autowired
private Cart cart;

@Autowired
private Order order;

@Autowired
private HttpSession httpsession;

@Autowired
private Product product;

public Order initFlow(){

}
